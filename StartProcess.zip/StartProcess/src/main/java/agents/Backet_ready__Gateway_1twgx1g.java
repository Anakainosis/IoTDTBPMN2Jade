package agents;

import jade.core.Agent;
import jade.core.AID;
import jade.lang.acl.ACLMessage;
import jade.core.behaviours.CyclicBehaviour;
import java.util.*;

public class Backet_ready__Gateway_1twgx1g extends Agent {
    private List<String> successors = Arrays.asList("insert_cassette_in_the_cassette_basket_Activity_1a0k1kp", "Sending_a_notification_about_the_cassette_basket_Activity_0jmae46");

    protected void setup() {
        addBehaviour(new ReceiveTokenBehaviour());
    }

    private class ReceiveTokenBehaviour extends CyclicBehaviour {
        public void action() {
            ACLMessage msg = receive();
            if (msg != null) {
                try {
                    Token token = (Token) msg.getContentObject();
                    token.addAgent(getLocalName());

                    if (successors.isEmpty()) {
                        // No successors, send to EndAgent
                        ACLMessage endMsg = new ACLMessage(ACLMessage.INFORM);
                        endMsg.addReceiver(new AID("EndAgent", AID.ISLOCALNAME));
                        endMsg.setContentObject(token);
                        send(endMsg);
                    } else {
                        // XOR Gateway - choose a random successor
                        Random rand = new Random();
        String nextAgent = successors.get(rand.nextInt(successors.size()));
                        ACLMessage forwardMsg = new ACLMessage(ACLMessage.INFORM);
                        forwardMsg.addReceiver(new AID(nextAgent, AID.ISLOCALNAME));
                        forwardMsg.setContentObject(token);
                        send(forwardMsg);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                block();
            }
        }
    }
}
