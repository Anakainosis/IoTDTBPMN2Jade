package startprocess;


import jade.core.Agent;
import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.core.Runtime;
import jade.wrapper.AgentController;
import jade.wrapper.ContainerController;

import java.io.File;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.*;
import java.util.HashMap;
import java.util.Map;

public class AgentRunner {

    private static final String AGENT_DIR = "c:/agent/agents"; // Katalog z plikami .class agentów

    public static void main(String[] args) throws Exception {
        // Inicjalizacja środowiska JADE
        Runtime rt = Runtime.instance();
        Profile p = new ProfileImpl();
        p.setParameter(Profile.GUI, "true"); // Włączenie GUI
        ContainerController cc = rt.createMainContainer(p);
        addAndStartSnifferAgent(cc);
        // Załaduj klasy agentów
        Map<String, Class<? extends Agent>> agentClasses = loadAgentClasses();

        // Utwórz agentów na platformie JADE
        createAgentsOnPlatform(cc, agentClasses);
        
        
        
        
    }

    private static void addAndStartSnifferAgent(ContainerController cc) {
        try {
            // Tworzenie agenta Sniffer
            AgentController sniffer = cc.createNewAgent("Sniffer", "jade.tools.sniffer.Sniffer", null);
            sniffer.start();
            System.out.println("Agent Sniffer został uruchomiony.");
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Błąd podczas uruchamiania agenta Sniffer.");
        }
    }
    
    // Ładowanie klas agentów
    private static Map<String, Class<? extends Agent>> loadAgentClasses() throws Exception {
        Map<String, Class<? extends Agent>> agentClasses = new HashMap<>();
        Path agentDir = Paths.get(AGENT_DIR);

        // Inicjalizacja ładowarki klas
        URLClassLoader classLoader = URLClassLoader.newInstance(
                new URL[]{new File("c:/agents").toURI().toURL()},
                Thread.currentThread().getContextClassLoader()
        );

        // Ładowanie klas agentów
        Files.walk(agentDir)
                .filter(path -> path.toString().endsWith(".class") && !path.getFileName().toString().contains("$"))
                .forEach(classFile -> {
                    String className = agentDir.relativize(classFile).toString()
                            .replace(".class", "")
                            .replace(File.separator, ".");
                    className = "agents." + className; // Dostosuj nazwę pakietu
                    try {
                        Class<?> cls = Class.forName(className, true, classLoader);
                        if (Agent.class.isAssignableFrom(cls)) {
                            agentClasses.put(cls.getSimpleName(), (Class<? extends Agent>) cls);
                        }
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    }
                });
        return agentClasses;
    }

    // Tworzenie agentów na platformie JADE
    private static void createAgentsOnPlatform(ContainerController cc, Map<String, Class<? extends Agent>> agentClasses) {
        for (Map.Entry<String, Class<? extends Agent>> entry : agentClasses.entrySet()) {
            try {
                String agentName = entry.getKey(); // np. "doit_Activity_0g3twow"
                String className = entry.getValue().getName(); // np. "agents.doit_Activity_0g3twow"
                System.out.println("Tworzenie agenta: " + agentName + " z klasą: " + className);
                AgentController agent = cc.createNewAgent(agentName, className, null);
                agent.start();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}

